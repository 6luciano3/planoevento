COLECCIÓN 10 — CANTEROS, ISLETAS Y VEGETACIÓN COMPLEMENTARIA

Contenido:
01. Cantero floral recto modular
02. Cantero floral curvo de 90 grados
03. Isleta de estacionamiento parquizada
04. Árbol nativo compacto
05. Conjunto subtropical mixto
06. Macizo floral multicolor
07. Separador verde lineal modular

Especificaciones:
- PNG individual con transparencia alfa real.
- Vista isométrica coherente para planos ilustrativos.
- Iluminación superior izquierda.
- Tierra colorada y vegetación inspirada en Misiones.
- Sin textos ni fondos incorporados.

Los elementos lineales pueden repetirse para construir bordes y separadores más largos.
