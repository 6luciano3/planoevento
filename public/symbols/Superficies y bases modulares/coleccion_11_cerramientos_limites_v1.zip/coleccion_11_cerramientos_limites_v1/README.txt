COLECCIÓN 11 — CERRAMIENTOS Y LÍMITES DEL PREDIO

Contenido:
01. Cerco perimetral recto modular
02. Cerco perimetral en esquina de 90 grados
03. Muro bajo recto modular
04. Portón vehicular de doble hoja
05. Acceso peatonal
06. Valla metálica móvil
07. Línea de cinco bolardos
08. Barrera vehicular levadiza
09. Límite vegetal lineal
10. Esquina parquizada de cierre

Especificaciones:
- PNG individual con transparencia alfa real.
- Vista isométrica coherente para planos ilustrativos.
- Iluminación superior izquierda.
- Materiales realistas y escala visual uniforme.
- Sin textos ni fondos incorporados.

Los elementos rectos y las esquinas son modulares y pueden repetirse para
construir perímetros de diferentes dimensiones.
